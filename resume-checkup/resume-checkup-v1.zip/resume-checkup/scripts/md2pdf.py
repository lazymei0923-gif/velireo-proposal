#!/usr/bin/env python3
"""把健檢報告的 Markdown 轉成 PDF。

用法：
    python3 md2pdf.py <報告.md> [輸出.pdf]

零外部依賴：自製 Markdown→HTML，再用 Chrome headless 列印成 PDF。
支援：標題、粗體、行內碼、表格、清單、引用、分隔線、emoji、中文。
"""

import html
import os
import re
import subprocess
import sys
import tempfile

CHROME_CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
]

CSS = """
@page { size: A4; margin: 16mm 14mm; }
* { box-sizing: border-box; }
body {
  font-family: "Noto Sans TC", "PingFang TC", "Heiti TC", "Microsoft JhengHei",
               -apple-system, "Helvetica Neue", sans-serif;
  font-size: 10.5pt; line-height: 1.65; color: #1c1c1e; margin: 0;
  -webkit-print-color-adjust: exact; print-color-adjust: exact;
}
h1 { font-size: 19pt; margin: 0 0 4pt; padding-bottom: 8pt;
     border-bottom: 2.5pt solid #C9817A; letter-spacing: .3pt; }
h2 { font-size: 13.5pt; margin: 20pt 0 6pt; padding-left: 8pt;
     border-left: 4pt solid #C9817A; page-break-after: avoid; }
h3 { font-size: 11.5pt; margin: 14pt 0 4pt; color: #444; page-break-after: avoid; }
p { margin: 5pt 0; }
ul, ol { margin: 5pt 0 5pt 0; padding-left: 18pt; }
li { margin: 2.5pt 0; }
li > strong:first-child { color: #8a4a44; }
strong { font-weight: 600; }
code { background: #f2f0ee; padding: 1pt 4pt; border-radius: 3pt;
       font-family: "SF Mono", Menlo, monospace; font-size: 9.5pt; }
blockquote { margin: 8pt 0; padding: 7pt 11pt; background: #faf7f5;
             border-left: 3pt solid #d9c2be; color: #4a4a4a; font-size: 10pt; }
blockquote p { margin: 0; }
hr { border: 0; border-top: 1pt solid #e5e0dc; margin: 16pt 0; }
table { border-collapse: collapse; width: 100%; margin: 8pt 0;
        font-size: 9.5pt; page-break-inside: avoid; }
th { background: #f5f1ee; text-align: left; font-weight: 600; }
th, td { border: .75pt solid #e0dad5; padding: 4.5pt 7pt; vertical-align: top; }
tr:nth-child(even) td { background: #fbfaf9; }
.meta { color: #8a8a8e; font-size: 9pt; margin-top: 2pt; }
"""

INLINE_CODE = re.compile(r"`([^`]+)`")
BOLD = re.compile(r"\*\*([^*]+)\*\*")
LINK = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")


def inline(text: str) -> str:
    """行內語法：先跳脫 HTML，再還原 **粗體**、`碼`、[連結]()。"""
    out = html.escape(text)
    out = INLINE_CODE.sub(lambda m: f"<code>{m.group(1)}</code>", out)
    out = BOLD.sub(lambda m: f"<strong>{m.group(1)}</strong>", out)
    out = LINK.sub(lambda m: f'<a href="{m.group(2)}">{m.group(1)}</a>', out)
    return out


def is_table_sep(line: str) -> bool:
    s = line.strip()
    return bool(s.startswith("|") and re.fullmatch(r"[|\s:\-]+", s))


def split_row(line: str) -> list:
    cells = line.strip().strip("|").split("|")
    return [c.strip() for c in cells]


def convert(md: str) -> str:
    lines = md.split("\n")
    out, i = [], 0
    list_open = None  # 'ul' | 'ol' | None

    def close_list():
        nonlocal list_open
        if list_open:
            out.append(f"</{list_open}>")
            list_open = None

    while i < len(lines):
        raw = lines[i]
        line = raw.rstrip()
        stripped = line.strip()

        # 表格：本行是 |...| 且下一行是分隔列
        if stripped.startswith("|") and i + 1 < len(lines) and is_table_sep(lines[i + 1]):
            close_list()
            header = split_row(line)
            i += 2
            body = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                body.append(split_row(lines[i]))
                i += 1
            out.append("<table><thead><tr>")
            out.extend(f"<th>{inline(c)}</th>" for c in header)
            out.append("</tr></thead><tbody>")
            for row in body:
                row += [""] * (len(header) - len(row))
                out.append("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in row[: len(header)]) + "</tr>")
            out.append("</tbody></table>")
            continue

        if not stripped:
            close_list()
            i += 1
            continue

        if stripped in ("---", "***", "___"):
            close_list()
            out.append("<hr>")
            i += 1
            continue

        m = re.match(r"^(#{1,4})\s+(.*)$", stripped)
        if m:
            close_list()
            lv = len(m.group(1))
            out.append(f"<h{lv}>{inline(m.group(2))}</h{lv}>")
            i += 1
            continue

        if stripped.startswith(">"):
            close_list()
            quote = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                quote.append(lines[i].strip().lstrip(">").strip())
                i += 1
            out.append(f"<blockquote><p>{inline(' '.join(quote))}</p></blockquote>")
            continue

        m = re.match(r"^\s*(?:[-*•]|\d+\.)\s+(.*)$", line)
        if m:
            ordered = bool(re.match(r"^\s*\d+\.", line))
            want = "ol" if ordered else "ul"
            if list_open != want:
                close_list()
                out.append(f"<{want}>")
                list_open = want
            out.append(f"<li>{inline(m.group(1))}</li>")
            i += 1
            continue

        close_list()
        out.append(f"<p>{inline(stripped)}</p>")
        i += 1

    close_list()
    return "\n".join(out)


def find_chrome() -> str:
    for p in CHROME_CANDIDATES:
        if os.path.exists(p):
            return p
    raise SystemExit("找不到 Chrome／Chromium／Edge，無法產生 PDF。請改用 Markdown 版。")


def main() -> None:
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    md_path = os.path.abspath(os.path.expanduser(sys.argv[1]))
    pdf_path = (os.path.abspath(os.path.expanduser(sys.argv[2]))
                if len(sys.argv) > 2 else os.path.splitext(md_path)[0] + ".pdf")

    with open(md_path, encoding="utf-8") as f:
        md = f.read()

    title = html.escape(next((l.lstrip("# ").strip() for l in md.split("\n")
                              if l.startswith("# ")), "履歷健檢報告"))
    doc = (f'<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="utf-8">'
           f"<title>{title}</title><style>{CSS}</style></head><body>"
           f"{convert(md)}</body></html>")

    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf-8") as tmp:
        tmp.write(doc)
        html_path = tmp.name

    try:
        subprocess.run(
            [find_chrome(), "--headless", "--disable-gpu", "--no-pdf-header-footer",
             f"--print-to-pdf={pdf_path}", f"file://{html_path}"],
            check=True, capture_output=True, timeout=90,
        )
    except subprocess.CalledProcessError as e:
        raise SystemExit(f"Chrome 轉檔失敗：{e.stderr.decode('utf-8', 'ignore')[:400]}")
    finally:
        os.unlink(html_path)

    if not os.path.exists(pdf_path):
        raise SystemExit("PDF 未產生，請改用 Markdown 版。")
    print(pdf_path)


if __name__ == "__main__":
    main()
